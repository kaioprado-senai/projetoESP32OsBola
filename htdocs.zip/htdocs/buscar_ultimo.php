<?php
include('connect.php');

$kph = $_POST["kph"];
$rpm = $_POST["rpm"];
$sql = "insert into monitoramento (rpm, kph) values ('$kph', '$rpm')"; 


$result = $conn->query($sql);
if ($result->num_rows > 0) {
$row = $result->fetch_assoc();
echo json_encode([
"rpm" => $row["rpm"],
"kph" => $row["kph"],
"exemplo" => $row["exemplo"]
]);
}
$conn->close();
?>